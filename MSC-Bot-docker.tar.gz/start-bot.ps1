param(
    [Parameter(Mandatory = $true)]
    [string]$AppPath,

    [int]$Port = 5000
)

# Absoluten Pfad ermitteln
$HostAppPath = (Resolve-Path $AppPath).Path

if (-not (Test-Path $HostAppPath -PathType Container)) {
    Write-Error "Directory does not exist: $HostAppPath"
    exit 1
}

# Containername = Ordnername
$ContainerName = Split-Path $HostAppPath -Leaf

Write-Host @"
Starting Docker container
  Name:       $ContainerName
  App folder: $HostAppPath
  Port:       $Port -> 5000
"@

docker pull mcr.microsoft.com/dotnet/sdk:10.0

# Falls bereits vorhanden
docker rm -f $ContainerName 2>$null | Out-Null

docker run --rm --name $ContainerName -d `
  -v "${HostAppPath}:/app" `
  -w /app `
  -p "${Port}:5000" `
  mcr.microsoft.com/dotnet/sdk:10.0 `
  sh -c "while true; do
           dotnet BotNix.ClientApp.dll;
           echo 'The bot has terminated. Restarting in 61 seconds...';
           sleep 61;
         done"