@echo off
setlocal enabledelayedexpansion

:: Define target folder, archive URL, and archive file name
set "targetfolder=%cd%"
set "archive_url=https://github.com/cfHxqA/Mission-Chief.Bot/raw/master/MSC-Bot.zip"

:: Extract the archive filename from the URL
for %%a in ("%archive_url%") do set "archive_file=%targetfolder%\%%~nxa"

:: Temporary folder for extraction
set "tempfolder=%targetfolder%\temp"

:: Define the array of files that should not be replaced
set "skip_files=config.json config.mscc config.conf"

:: Check if .NET 10 SDK is installed
echo Checking if .NET 10 SDK is installed...
dotnet --list-sdks | findstr /i "10." > nul
if %errorlevel% neq 0 (
    echo .NET 10 SDK not found. Installing now...
    :: Download and install .NET SDK 10
    set "dotnet_url=https://download.visualstudio.microsoft.com/download/pr/207c0729-5924-4881-83a5-d9fd639bb7ed/23b4d5805bc7e1cd52069c4b0432356e/dotnet-sdk-10.0.0-win-x64.exe"
    set "dotnet_installer=%temp%\dotnet-sdk-10-installer.exe"
    
    :: Download the installer
    powershell -Command "(New-Object Net.WebClient).DownloadFile('%dotnet_url%', '%dotnet_installer%')"
    
    :: Run the installer
    echo Installing .NET 10 SDK...
    start /wait %dotnet_installer% /quiet /norestart
    
    :: Check if installation was successful
    dotnet --list-sdks | findstr /i "10." > nul
    if %errorlevel% neq 0 (
        echo Error: .NET 10 SDK installation failed.
        exit /b 1
    ) else (
        echo .NET 10 SDK installed successfully.
    )
)

:: Download the archive
echo Downloading archive from %archive_url%...
powershell -Command "(New-Object Net.WebClient).DownloadFile('%archive_url%', '%archive_file%')"

:: Create temporary folder
echo Extracting archive...
mkdir "%tempfolder%"

:: Extract the archive
powershell -Command "Expand-Archive -Path '%archive_file%' -DestinationPath '%tempfolder%'"

:: Replace files from the archive, except config.json, config.mscc, and config.conf
echo Replacing files in the target folder, skipping config.json, config.mscc, and config.conf...

for /r "%tempfolder%" %%f in (*) do (
    set "tempfile=%%f"
    set "targetfile=%targetfolder%\!tempfile:%tempfolder%\=%!"

    :: Check if the file is in the skip list
    set "skip=0"
    for %%i in (%skip_files%) do (
        if /i "!targetfile!"=="%targetfolder%\%%i" set "skip=1"
    )

    :: If the file is not in the skip list, replace it
    if !skip! neq 1 (
        echo Replacing: !targetfile!
        copy /y "!tempfile!" "!targetfile!"
    ) else (
        echo Skipping: !targetfile!
    )
)

:: Clean up temporary folder
rd /s /q "%tempfolder%"

:: Delete the archive
del "%archive_file%"

echo Done!
pause