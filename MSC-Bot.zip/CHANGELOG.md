+ CHANGES Missions,
  - Fixed that the standard vehicles are sent to EVERY mission when released
  - Fixed that an error was caused when the follow-up is present

+ Mandatory, 
  - Error and source code optimization
  - Source code viewed, lines of code counted