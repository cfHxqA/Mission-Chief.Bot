+ CHANGES Missions,
  - Fixed that releases are incorrect (partly NOT released, wrong)
  - Fixed that clearances are closed despite declared vehicles
  - Fixed that own missions are NOT alerted

+ Mandatory, 
  - Error and source code optimization
  - Source code viewed, lines of code counted