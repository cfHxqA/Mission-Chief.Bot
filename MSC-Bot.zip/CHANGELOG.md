+ CHANGES MISSION,
  - Distance calculation of the vehicles
  - Integrated "follow-up", (only reacts to final missions - no other vehicles required, mission is ended)
  - Sorting of the missions follows strictly after creation

+ Mandatory, 
  - Error and source code optimization
  - Source code viewed, lines of code counted