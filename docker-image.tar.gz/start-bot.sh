#!/bin/bash

# --------------------------------------------
# Usage:
#   ./start-bot.sh <container-name> [app-folder]
#
# Examples:
#   ./start-bot.sh bot1 app1
#   ./start-bot.sh bot2 app2
#   ./start-bot.sh bot-main
# --------------------------------------------

# Require container name
if [ -z "$1" ]; then
  echo "Usage: ./start-bot.sh <container-name> [app-folder]"
  exit 1
fi

CONTAINER_NAME="$1"

# Determine script directory (absolute)
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Determine app folder
if [ -z "$2" ]; then
  APP_PATH="$SCRIPT_DIR/app"
  echo "No app folder provided. Using default: $APP_PATH"
else
  APP_PATH="$SCRIPT_DIR/$2"
  echo "Using specified app folder: $APP_PATH"
fi

# Validate directory exists
if [ ! -d "$APP_PATH" ]; then
  echo "Error: App directory does not exist: $APP_PATH"
  exit 1
fi

# Pull images defined in docker-compose.yml
docker-compose pull

# Start container
echo "Starting Docker container: $CONTAINER_NAME using $APP_PATH"
docker-compose pull && docker run --rm --name "$CONTAINER_NAME" -d \
  -v "$APP_PATH:/app" \
  -w /app \
  mcr.microsoft.com/dotnet/sdk:9.0 \
  sh -c "while true; do
           dotnet BotNix.App.dll;
           echo 'The bot has terminated. Restarting in 61 seconds...';
           sleep 61;
         done"