# start-bot.ps1
param(
    [Parameter(Mandatory=$true)]
    [string]$ContainerName,
    [string]$AppFolder = "app"
)

# Absoluter Pfad zum Skriptverzeichnis
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition

# Host‑Pfad bestimmen
$HostAppPath = Join-Path $ScriptDir $AppFolder

if (-not (Test-Path $HostAppPath -PathType Container)) {
    Write-Error "Error: Directory does not exist: $HostAppPath"
    exit 1
}

Write-Host "Starting Docker container:`n  Name: $ContainerName`n  App folder: $HostAppPath"

# .NET SDK 9.0 Image pullen (optional)
docker pull mcr.microsoft.com/dotnet/sdk:9.0

# Container starten
docker run --rm --name $ContainerName -d `
  -v "${HostAppPath}:/app" `
  -w /app `
  mcr.microsoft.com/dotnet/sdk:9.0 `
  sh -c "while true; do
           dotnet BotNix.App.dll;
           echo 'The bot has terminated. Restarting in 61 seconds...';
           sleep 61;
         done"